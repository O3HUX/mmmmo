package net.pand0ra.o3hux.atmosphere;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class AtmosphereConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH =
            FabricLoader.getInstance().getConfigDir().resolve("atmosphere.json");

    private static AtmosphereConfig INSTANCE = new AtmosphereConfig();

    public boolean snowEnabled = true;
    public boolean particlesEnabled = true;
    public float particleDensity = 1.0f;
    public float fogVisibility = 1.0f;
    public boolean warmLight = true;
    public float warmLightStrength = 1.0f;

    public static AtmosphereConfig get() {
        return INSTANCE;
    }

    public static void load() {
        if (Files.exists(CONFIG_PATH)) {
            try {
                String json = Files.readString(CONFIG_PATH);
                AtmosphereConfig loaded = GSON.fromJson(json, AtmosphereConfig.class);
                if (loaded != null) {
                    INSTANCE = loaded;
                }
            } catch (IOException ignored) {
            }
        }
        save();
    }

    public static void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Files.writeString(CONFIG_PATH, GSON.toJson(INSTANCE));
        } catch (IOException ignored) {
        }
    }
}
