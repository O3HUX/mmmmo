package net.pand0ra.o3hux.atmosphere.mixin;

import net.minecraft.client.world.ClientWorld;
import net.pand0ra.o3hux.atmosphere.AtmosphereConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientWorld.class)
public class ClientWorldMixin {
    @Inject(method = "getRainGradient", at = @At("HEAD"), cancellable = true)
    private void forceRainGradient(float delta, CallbackInfoReturnable<Float> cir) {
        AtmosphereConfig cfg = AtmosphereConfig.get();
        if (!cfg.particlesEnabled) {
            cir.setReturnValue(0.0f);
        } else {
            cir.setReturnValue(cfg.particleDensity);
        }
    }

    @Inject(method = "getThunderGradient", at = @At("HEAD"), cancellable = true)
    private void forceThunderGradient(float delta, CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue(0.0f);
    }
}
