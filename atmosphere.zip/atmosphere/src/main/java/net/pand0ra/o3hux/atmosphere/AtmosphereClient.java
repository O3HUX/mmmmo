package net.pand0ra.o3hux.atmosphere;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.pand0ra.o3hux.atmosphere.gui.AtmosphereMenuScreen;
import org.lwjgl.glfw.GLFW;

public class AtmosphereClient implements ClientModInitializer {
    public static final String MOD_ID = "atmosphere";
    private static KeyBinding menuKeyBinding;

    @Override
    public void onInitializeClient() {
        AtmosphereConfig.load();

        menuKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.atmosphere.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                "category.atmosphere"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKeyBinding.wasPressed()) {
                if (client.player != null) {
                    client.setScreen(new AtmosphereMenuScreen());
                }
            }
        });
    }
}
